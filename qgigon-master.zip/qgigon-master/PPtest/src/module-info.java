module PPtest {
	
	int x;
}