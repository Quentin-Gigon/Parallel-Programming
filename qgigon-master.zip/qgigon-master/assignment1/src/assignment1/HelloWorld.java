package assignment1;

/* This is a class */
public class HelloWorld {
	/*
	 * This is the main method. This is the entry point for your program.
	 */
	public static void main(String[] arguments) {
		/* Output Hello World to the console */
		System.out.println("Hello World");
	}
}